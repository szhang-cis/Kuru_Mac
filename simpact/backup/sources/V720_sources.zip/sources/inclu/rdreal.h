      INTEGER, PARAMETER :: maxnr = 40
      INTEGER (kind=4) nreal
      REAL    (kind=8) reard(maxnr)
