 SUBROUTINE rdrfd0 (iwrit)

 !This routine reads rotation-free dependent nodes (nrfdp)

 IMPLICIT NONE
 INTEGER :: iwrit

 END SUBROUTINE rdrfd0
