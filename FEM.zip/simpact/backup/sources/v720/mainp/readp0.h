      SUBROUTINE readp0 (iwrit,actio)
      
      !This routine reads dependent nodes (nndp)
      
      IMPLICIT NONE
      CHARACTER(len=*),INTENT(IN):: actio
      INTEGER(kind=4):: iwrit
      
      END SUBROUTINE readp0

