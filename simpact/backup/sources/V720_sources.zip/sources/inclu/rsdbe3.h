      SUBROUTINE rsdbe3 (pair, itask)

      USE db3_db
      IMPLICIT NONE

      !   d u m m y   a r g u m e n t s

      CHARACTER (LEN=*), INTENT (IN) :: itask
      TYPE (db3pair_db) :: pair

      END SUBROUTINE rsdbe3
