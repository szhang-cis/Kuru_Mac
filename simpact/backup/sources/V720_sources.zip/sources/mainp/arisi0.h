 SUBROUTINE arisi0 (naris,iwrit,actio)

 ! reads data for nodes fixed on a side (narisn)

 IMPLICIT NONE
 CHARACTER(len=* ), INTENT(IN OUT) :: actio
 INTEGER, INTENT(IN) :: iwrit
 INTEGER, INTENT(IN OUT) :: naris
 END SUBROUTINE arisi0
