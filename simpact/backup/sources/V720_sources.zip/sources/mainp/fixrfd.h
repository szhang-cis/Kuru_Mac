 SUBROUTINE fixrfd(x)
 !***********************************************************************
 !
 !     updates configuration and factors of dependant displacements
 !
 !***********************************************************************
 IMPLICIT NONE
 REAL (kind=8),INTENT(IN OUT) :: x(:,:)

 END SUBROUTINE fixrfd
