      SUBROUTINE endstr
!********************************************************************
!
!*** END STRATEGY card READ
!
!********************************************************************
      IMPLICIT NONE

      END SUBROUTINE endstr
