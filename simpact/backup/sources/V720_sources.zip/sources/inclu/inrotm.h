SUBROUTINE inrotm(a,euler)
!***************************************************************
!     calculates the initial nodal coordinate systems
!***************************************************************
IMPLICIT NONE

REAL (kind=8),INTENT(IN) :: a(3)
REAL (kind=8),INTENT(OUT) :: euler(9)

END SUBROUTINE inrotm
