      SUBROUTINE actrot(lambda,theta)
      IMPLICIT NONE
      REAL (kind=8),INTENT(IN) :: THETA(3)
      REAL (kind=8),INTENT(IN OUT) :: LAMBDA(3,3)
      END SUBROUTINE actrot
