 SUBROUTINE mase22(nnode,nelem,matno,lnods,sname)

 !USE c_input, ONLY : openfi
 IMPLICIT NONE
 INTEGER (kind=4) nnode,nelem,matno(nelem),lnods(nnode,nelem)
 CHARACTER (len=*) :: sname

 END SUBROUTINE mase22
