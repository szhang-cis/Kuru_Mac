 SUBROUTINE nodn07( nelem,lnods,coord,eule0,euler)

 INTEGER (kind=4), INTENT(IN) :: nelem,lnods(:,:)
 REAL (kind=8), INTENT(IN) :: coord(:,:)
 REAL (kind=8), INTENT(IN OUT) :: eule0(:,:),euler(:,:)

 END SUBROUTINE nodn07
