 SUBROUTINE inpd10 (task, ndime,nelem,iwrit,elsnam,nelms)
 !*****************************************************************
 !
 !*** READ control DATA
 !
 !*****************************************************************

 IMPLICIT NONE
 !     routine parameters

 CHARACTER(len=*),INTENT(IN):: elsnam
 CHARACTER(len=*),INTENT(IN):: task
 INTEGER (kind=4) ndime,nelem,nelms,iwrit

 END SUBROUTINE inpd10
