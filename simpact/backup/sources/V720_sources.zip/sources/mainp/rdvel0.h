      SUBROUTINE rdvel0 (iwrit,ndime,ndofn,actio,nvelr)

  !This routine reads prescribed velocities

      CHARACTER(len=*),INTENT(IN):: actio
      INTEGER(kind=4) :: iwrit,ndime,ndofn,nvelr

      END SUBROUTINE rdvel0
