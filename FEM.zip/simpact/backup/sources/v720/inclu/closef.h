      SUBROUTINE closef(nreqd,nreqv,nreqa,nreqc,ncont)

      IMPLICIT NONE
      INTEGER (kind=4),INTENT(IN) :: nreqd,nreqv,nreqa,nreqc,ncont

      END SUBROUTINE closef
