      SUBROUTINE renum2(adjnt,start,level,lpntn,npoin,ns)
      IMPLICIT none
      INTEGER (kind=4),INTENT(IN) :: adjnt(1:),npoin
      INTEGER (kind=4),INTENT(OUT):: lpntn(:),level(1:),start(1:),ns
      END SUBROUTINE renum2
