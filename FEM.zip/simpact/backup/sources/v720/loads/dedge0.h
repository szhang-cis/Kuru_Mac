      SUBROUTINE dedge0(nedge,ndime,iwrit,heade,taile)
!     Reads line distributed loads
      USE loa_db
      IMPLICIT NONE
      INTEGER (kind=4) :: nedge,ndime,iwrit
      TYPE (edg_nod),POINTER :: heade, taile

      END SUBROUTINE dedge0
