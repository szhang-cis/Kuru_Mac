      SUBROUTINE rdload (iwrit,ndime,ndofn,nload)

      !This routine reads load sets (nodal loads, edge and surface loads)

      IMPLICIT NONE
      INTEGER(kind=4):: iwrit,ndime,ndofn,nload

      END SUBROUTINE rdload
