      SUBROUTINE renum3(adjnt,start,level,lpntn,npoin,i)
      IMPLICIT none
      INTEGER (kind=4),INTENT(IN) :: npoin,i,adjnt(1:)
      INTEGER (kind=4),INTENT(OUT):: lpntn(:),start(1:),level(1:)
      END SUBROUTINE renum3
