 SUBROUTINE immtsc (nf,nm,ns,mn,sn)
 !
 !   import materials and sections
 !
 IMPLICIT NONE

 INTEGER(kind=4) :: nf,nm,ns
 INTEGER(kind=4) :: mn(2,nm),sn(2,ns)

 END SUBROUTINE immtsc
