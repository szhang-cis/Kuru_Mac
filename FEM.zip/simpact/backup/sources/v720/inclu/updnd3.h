SUBROUTINE updnd3(oldlb,nmn,nrtm,msr,irect,keep)
!***********************************************************************
!
!*** updates internal node numbering for 3D drawbeads
!
!***********************************************************************
  IMPLICIT NONE
! Arguments
  INTEGER (kind=4) oldlb(:), nmn, nrtm, msr(:), irect(:,:)
  LOGICAL :: keep

END SUBROUTINE updnd3
