      SUBROUTINE outdyn(inicia, foutp, ecdis)
!***********************************************************************
!
!** output routine
!
!***********************************************************************
      IMPLICIT NONE

      LOGICAL, INTENT(IN) :: foutp, inicia
      INTEGER (kind=4),INTENT(IN) :: ecdis

      END SUBROUTINE outdyn
