      SUBROUTINE SORTND(A,N)
      implicit none
      INTEGER (kind=4) :: A(*),N
      END
