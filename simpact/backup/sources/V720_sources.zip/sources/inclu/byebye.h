      SUBROUTINE byebye (time)
      IMPLICIT NONE
      REAL (kind=8),INTENT(IN OUT) :: time(:)
      END SUBROUTINE byebye
