        SUBROUTINE reasd0 (iwrit,actio)
       
        CHARACTER(len=*),INTENT(IN):: actio
        INTEGER(kind=4):: iwrit

        END SUBROUTINE reasd0
